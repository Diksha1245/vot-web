// Application Data (simulating Firebase/API storage)
const applicationData = {
  "voters": [
    {
      "id": "V001",
      "name": "John Smith", 
      "email": "john.smith@email.com",
      "registration_date": "2024-01-15",
      "face_encoding": [0.1, -0.2, 0.5, 0.8, -0.1, 0.3, 0.7, -0.4],
      "status": "active"
    },
    {
      "id": "V002", 
      "name": "Sarah Johnson",
      "email": "sarah.j@email.com", 
      "registration_date": "2024-01-16",
      "face_encoding": [-0.3, 0.4, -0.1, 0.6, 0.2, -0.5, 0.1, 0.9],
      "status": "active"
    }
  ],
  "authentication_logs": [
    {
      "timestamp": "2024-01-20T10:30:00Z",
      "voter_id": "V001",
      "voter_name": "John Smith", 
      "result": "success",
      "confidence": 0.95
    },
    {
      "timestamp": "2024-01-20T11:45:00Z", 
      "voter_id": "V002",
      "voter_name": "Sarah Johnson",
      "result": "success", 
      "confidence": 0.92
    }
  ],
  "system_stats": {
    "total_registered": 2,
    "successful_auths_today": 2,
    "system_accuracy": "95.2%",
    "uptime": "99.8%"
  }
};

// Application State
class VoterFRS {
  constructor() {
    this.currentPage = 'home';
    this.isRegistering = false;
    this.isAuthenticating = false;
    this.registerStream = null;
    this.authStream = null;
    this.faceDetectionInterval = null;
    this.capturedFaceData = null;
    
    this.init();
  }

  init() {
    this.setupNavigation();
    this.setupRegistration();
    this.setupAuthentication();
    this.loadDashboard();
    this.showToast('System initialized successfully', 'success');
  }

  // Navigation System
  setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    const heroButtons = document.querySelectorAll('[data-navigate]');

    navLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const page = link.getAttribute('data-page');
        this.navigateToPage(page);
      });
    });

    heroButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.preventDefault();
        const page = button.getAttribute('data-navigate');
        this.navigateToPage(page);
      });
    });
  }

  navigateToPage(page) {
    // Hide all pages
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    
    // Remove active class from nav links
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
    
    // Show target page
    document.getElementById(`${page}-page`).classList.add('active');
    
    // Add active class to corresponding nav link
    document.querySelector(`[data-page="${page}"]`).classList.add('active');
    
    this.currentPage = page;

    // Stop any active streams when navigating away
    if (page !== 'register') {
      this.stopRegistrationCamera();
    }
    if (page !== 'authenticate') {
      this.stopAuthenticationCamera();
    }

    // Load page-specific data
    if (page === 'dashboard') {
      this.loadDashboard();
    }
  }

  // Registration System
  setupRegistration() {
    const startCameraBtn = document.getElementById('start-camera-btn');
    const captureFaceBtn = document.getElementById('capture-face-btn');
    const registrationForm = document.getElementById('registration-form');

    startCameraBtn.addEventListener('click', () => this.startRegistrationCamera());
    captureFaceBtn.addEventListener('click', () => this.captureFace());
    registrationForm.addEventListener('submit', (e) => this.submitRegistration(e));
  }

  async startRegistrationCamera() {
    try {
      const video = document.getElementById('register-video');
      const statusDiv = document.getElementById('camera-status');
      
      statusDiv.className = 'status-indicator waiting';
      statusDiv.textContent = 'Starting camera...';

      this.registerStream = await navigator.mediaDevices.getUserMedia({ video: true });
      video.srcObject = this.registerStream;

      statusDiv.className = 'status-indicator detecting';
      statusDiv.textContent = 'Camera active - Position your face in frame';

      document.getElementById('start-camera-btn').disabled = true;
      document.getElementById('capture-face-btn').disabled = false;

      // Start face detection simulation
      this.startFaceDetection('register');

    } catch (error) {
      console.error('Camera access denied:', error);
      this.showToast('Camera access denied. Please allow camera permissions.', 'error');
      document.getElementById('camera-status').className = 'status-indicator error';
      document.getElementById('camera-status').textContent = 'Camera access denied';
    }
  }

  stopRegistrationCamera() {
    if (this.registerStream) {
      this.registerStream.getTracks().forEach(track => track.stop());
      this.registerStream = null;
    }
    if (this.faceDetectionInterval) {
      clearInterval(this.faceDetectionInterval);
    }
    document.getElementById('start-camera-btn').disabled = false;
    document.getElementById('capture-face-btn').disabled = true;
  }

  startFaceDetection(mode) {
    const detectionBox = document.getElementById(`${mode}-detection-box`);
    
    this.faceDetectionInterval = setInterval(() => {
      // Simulate face detection
      const faceDetected = Math.random() > 0.3; // 70% chance of detecting face
      
      if (faceDetected) {
        // Show detection box with random position (simulated face location)
        const x = 20 + Math.random() * 40; // 20-60% from left
        const y = 15 + Math.random() * 30; // 15-45% from top
        const width = 25 + Math.random() * 15; // 25-40% width
        const height = 30 + Math.random() * 20; // 30-50% height

        detectionBox.style.left = `${x}%`;
        detectionBox.style.top = `${y}%`;
        detectionBox.style.width = `${width}%`;
        detectionBox.style.height = `${height}%`;
        detectionBox.classList.add('visible');
      } else {
        detectionBox.classList.remove('visible');
      }
    }, 200);
  }

  async captureFace() {
    const video = document.getElementById('register-video');
    const canvas = document.getElementById('register-canvas');
    const statusDiv = document.getElementById('camera-status');
    const countdownDiv = document.getElementById('capture-countdown');
    
    // Show countdown
    countdownDiv.classList.remove('hidden');
    for (let i = 3; i > 0; i--) {
      countdownDiv.textContent = i;
      await this.sleep(1000);
    }
    countdownDiv.classList.add('hidden');

    // Capture frame
    const context = canvas.getContext('2d');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0);

    // Convert to base64
    const imageData = canvas.toDataURL('image/jpeg', 0.8);
    
    // Show preview
    const previewImg = document.getElementById('captured-face-img');
    const qualityScore = document.getElementById('face-quality-score');
    
    previewImg.src = imageData;
    previewImg.classList.remove('hidden');
    
    // Simulate quality score
    const quality = 85 + Math.random() * 10;
    qualityScore.textContent = `Face Quality: ${quality.toFixed(1)}%`;
    qualityScore.classList.remove('hidden');

    // Store captured data
    this.capturedFaceData = {
      image: imageData,
      encoding: this.generateFaceEncoding(), // Simulate face encoding
      quality: quality
    };

    statusDiv.className = 'status-indicator success';
    statusDiv.textContent = 'Face captured successfully!';

    document.getElementById('submit-registration').disabled = false;
    this.showToast('Face captured successfully!', 'success');
  }

  generateFaceEncoding() {
    // Generate 128-dimensional face encoding (simulation)
    const encoding = [];
    for (let i = 0; i < 128; i++) {
      encoding.push(Math.random() * 2 - 1); // Random values between -1 and 1
    }
    return encoding;
  }

  async submitRegistration(e) {
    e.preventDefault();
    
    if (!this.capturedFaceData) {
      this.showToast('Please capture your face first', 'error');
      return;
    }

    this.showLoading('Registering voter...');

    const formData = new FormData(e.target);
    const voterData = {
      id: `V${String(applicationData.voters.length + 1).padStart(3, '0')}`,
      name: formData.get('voter-name') || document.getElementById('voter-name').value,
      email: formData.get('voter-email') || document.getElementById('voter-email').value,
      voter_id: formData.get('voter-id') || document.getElementById('voter-id').value,
      registration_date: new Date().toISOString().split('T')[0],
      face_encoding: this.capturedFaceData.encoding,
      face_image: this.capturedFaceData.image,
      status: 'active'
    };

    // Simulate API call delay
    await this.sleep(2000);

    // Add to application data
    applicationData.voters.push(voterData);
    applicationData.system_stats.total_registered = applicationData.voters.length;

    this.hideLoading();
    this.showToast('Registration completed successfully!', 'success');
    
    // Reset form
    document.getElementById('registration-form').reset();
    document.getElementById('captured-face-img').classList.add('hidden');
    document.getElementById('face-quality-score').classList.add('hidden');
    document.getElementById('submit-registration').disabled = true;
    
    this.stopRegistrationCamera();
    
    // Navigate to dashboard after successful registration
    setTimeout(() => {
      this.navigateToPage('dashboard');
    }, 1500);
  }

  // Authentication System
  setupAuthentication() {
    const startAuthBtn = document.getElementById('start-auth-camera-btn');
    const authenticateBtn = document.getElementById('authenticate-btn');

    startAuthBtn.addEventListener('click', () => this.startAuthenticationCamera());
    authenticateBtn.addEventListener('click', () => this.performAuthentication());
  }

  async startAuthenticationCamera() {
    try {
      const video = document.getElementById('auth-video');
      const statusDiv = document.getElementById('auth-status');
      
      statusDiv.className = 'status-indicator waiting';
      statusDiv.textContent = 'Starting camera...';

      this.authStream = await navigator.mediaDevices.getUserMedia({ video: true });
      video.srcObject = this.authStream;

      statusDiv.className = 'status-indicator detecting';
      statusDiv.textContent = 'Camera active - Look directly at camera';

      document.getElementById('start-auth-camera-btn').disabled = true;
      document.getElementById('authenticate-btn').disabled = false;

      // Start face detection
      this.startFaceDetection('auth');

    } catch (error) {
      console.error('Camera access denied:', error);
      this.showToast('Camera access denied. Please allow camera permissions.', 'error');
      document.getElementById('auth-status').className = 'status-indicator error';
      document.getElementById('auth-status').textContent = 'Camera access denied';
    }
  }

  stopAuthenticationCamera() {
    if (this.authStream) {
      this.authStream.getTracks().forEach(track => track.stop());
      this.authStream = null;
    }
    if (this.faceDetectionInterval) {
      clearInterval(this.faceDetectionInterval);
    }
    document.getElementById('start-auth-camera-btn').disabled = false;
    document.getElementById('authenticate-btn').disabled = true;
  }

  async performAuthentication() {
    const video = document.getElementById('auth-video');
    const canvas = document.getElementById('auth-canvas');
    const statusDiv = document.getElementById('auth-status');
    const resultsDiv = document.getElementById('auth-results');

    this.showLoading('Analyzing face...');
    statusDiv.className = 'status-indicator waiting';
    statusDiv.textContent = 'Processing authentication...';

    // Capture current frame
    const context = canvas.getContext('2d');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0);

    // Generate face encoding for current capture
    const currentEncoding = this.generateFaceEncoding();

    // Simulate face matching process
    await this.sleep(2000);

    let bestMatch = null;
    let highestConfidence = 0;

    // Compare with registered voters
    applicationData.voters.forEach(voter => {
      const similarity = this.calculateSimilarity(currentEncoding, voter.face_encoding);
      if (similarity > highestConfidence) {
        highestConfidence = similarity;
        bestMatch = voter;
      }
    });

    this.hideLoading();

    // Determine authentication result
    const threshold = 0.85;
    const isAuthenticated = highestConfidence >= threshold;
    
    // Update UI with results
    resultsDiv.classList.remove('hidden');
    const resultStatus = document.getElementById('auth-result-status');
    const confidenceScore = document.getElementById('confidence-score');
    const voterDetails = document.getElementById('voter-details');

    if (isAuthenticated && bestMatch) {
      resultStatus.className = 'result-status success';
      resultStatus.textContent = '✅ Authentication Successful';
      confidenceScore.textContent = `Confidence: ${(highestConfidence * 100).toFixed(1)}%`;
      
      // Show voter details
      document.getElementById('authenticated-name').textContent = bestMatch.name;
      document.getElementById('authenticated-id').textContent = bestMatch.id;
      document.getElementById('authenticated-date').textContent = bestMatch.registration_date;
      voterDetails.classList.remove('hidden');

      statusDiv.className = 'status-indicator success';
      statusDiv.textContent = 'Authentication successful!';

      // Add to authentication logs
      applicationData.authentication_logs.unshift({
        timestamp: new Date().toISOString(),
        voter_id: bestMatch.id,
        voter_name: bestMatch.name,
        result: 'success',
        confidence: highestConfidence
      });

      applicationData.system_stats.successful_auths_today++;

      this.showToast(`Welcome, ${bestMatch.name}!`, 'success');

    } else {
      resultStatus.className = 'result-status failure';
      resultStatus.textContent = '❌ Authentication Failed';
      confidenceScore.textContent = `Confidence: ${(highestConfidence * 100).toFixed(1)}% (Below threshold)`;
      voterDetails.classList.add('hidden');

      statusDiv.className = 'status-indicator error';
      statusDiv.textContent = 'Authentication failed - Face not recognized';

      // Add failed attempt to logs
      applicationData.authentication_logs.unshift({
        timestamp: new Date().toISOString(),
        voter_id: 'UNKNOWN',
        voter_name: 'Unknown User',
        result: 'failure',
        confidence: highestConfidence
      });

      this.showToast('Authentication failed - Face not recognized', 'error');
    }
  }

  calculateSimilarity(encoding1, encoding2) {
    // Simulate face similarity calculation using cosine similarity
    let dotProduct = 0;
    let norm1 = 0;
    let norm2 = 0;
    
    // Use first 8 dimensions for simulation
    const dim = Math.min(8, encoding1.length, encoding2.length);
    
    for (let i = 0; i < dim; i++) {
      dotProduct += encoding1[i] * encoding2[i];
      norm1 += encoding1[i] * encoding1[i];
      norm2 += encoding2[i] * encoding2[i];
    }
    
    const similarity = dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
    
    // Add some randomness to make it more realistic
    const noise = (Math.random() - 0.5) * 0.1;
    const finalSimilarity = Math.max(0, Math.min(1, similarity + noise + 0.5));
    
    // Boost similarity for demo purposes if close match
    return finalSimilarity > 0.7 ? Math.min(1, finalSimilarity + 0.15) : finalSimilarity;
  }

  // Dashboard System
  loadDashboard() {
    // Update statistics
    document.getElementById('total-voters').textContent = applicationData.system_stats.total_registered;
    document.getElementById('successful-auths').textContent = applicationData.system_stats.successful_auths_today;
    document.getElementById('system-accuracy').textContent = applicationData.system_stats.system_accuracy;
    document.getElementById('system-uptime').textContent = applicationData.system_stats.uptime;

    // Load authentication logs
    this.loadAuthenticationLogs();
    
    // Load voters table
    this.loadVotersTable();
  }

  loadAuthenticationLogs() {
    const tbody = document.getElementById('auth-logs-table');
    tbody.innerHTML = '';

    applicationData.authentication_logs.slice(0, 10).forEach(log => {
      const row = document.createElement('tr');
      
      const timestamp = new Date(log.timestamp);
      const formattedTime = timestamp.toLocaleString();
      
      row.innerHTML = `
        <td>${formattedTime}</td>
        <td>${log.voter_name}</td>
        <td><span class="status status--${log.result === 'success' ? 'success' : 'error'}">${log.result}</span></td>
        <td>${(log.confidence * 100).toFixed(1)}%</td>
      `;
      
      tbody.appendChild(row);
    });
  }

  loadVotersTable() {
    const tbody = document.getElementById('voters-table');
    tbody.innerHTML = '';

    applicationData.voters.forEach(voter => {
      const row = document.createElement('tr');
      
      row.innerHTML = `
        <td>${voter.id}</td>
        <td>${voter.name}</td>
        <td>${voter.email}</td>
        <td><span class="status status--success">${voter.status}</span></td>
        <td>${voter.registration_date}</td>
      `;
      
      tbody.appendChild(row);
    });
  }

  // Utility Functions
  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    const icon = type === 'success' ? '✅' : 
                 type === 'error' ? '❌' : 
                 type === 'warning' ? '⚠️' : 'ℹ️';
    
    toast.innerHTML = `
      <span>${icon}</span>
      <span>${message}</span>
    `;
    
    container.appendChild(toast);
    
    // Remove toast after 5 seconds
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast);
      }
    }, 5000);
  }

  showLoading(message = 'Processing...') {
    const overlay = document.getElementById('loading-overlay');
    const text = document.querySelector('.loading-text');
    text.textContent = message;
    overlay.classList.remove('hidden');
  }

  hideLoading() {
    const overlay = document.getElementById('loading-overlay');
    overlay.classList.add('hidden');
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
  window.voterFRS = new VoterFRS();
});

// Handle page visibility change to pause/resume camera
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    // Page is hidden, pause camera operations
    if (window.voterFRS) {
      if (window.voterFRS.faceDetectionInterval) {
        clearInterval(window.voterFRS.faceDetectionInterval);
      }
    }
  } else {
    // Page is visible, resume operations if needed
    if (window.voterFRS && window.voterFRS.currentPage === 'register' && window.voterFRS.registerStream) {
      window.voterFRS.startFaceDetection('register');
    }
    if (window.voterFRS && window.voterFRS.currentPage === 'authenticate' && window.voterFRS.authStream) {
      window.voterFRS.startFaceDetection('auth');
    }
  }
});

// Handle window beforeunload to cleanup streams
window.addEventListener('beforeunload', () => {
  if (window.voterFRS) {
    window.voterFRS.stopRegistrationCamera();
    window.voterFRS.stopAuthenticationCamera();
  }
});